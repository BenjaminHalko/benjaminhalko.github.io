# John's Quest

You are John Appleby, game historian.

## Story

Your shadow twin, Evil John, consumed by envy, has unleashed chaos across the realms. With his army of Evil Eyes, he has corrupted the land and caused genres to collide.

Can you use your expertise in gaming to restore peace to the world?

## Features

- Multi-Genre Adventure: Every level is different, thanks to Evil John
- Rhythm-based Platforming: Everything moves in time with the music
- Sword-based Combat: Includes "Bomb-based Combat" as well
- Mouse-based Movement: Simply click where you want to go
- Laser-based Gun: You shoot lasers... with a gun (that's it)
- Multi-Phase Boss Battles: Take on Evil John in deadly fights
- Humor: Maybe
- Play as John: Arguably the most important feature

## Details

- Price: Free
- Release Date: Feb 27, 2026
- Developer: Benjamin Halko
- Playtime: 40 minutes
- Stores: Steam, itch.io
- Platforms: PC, MacOS, Linux
- Tags: 2D Platformer, Action RPG, Point & Click, Twin Stick Shooter, Multi-genre, Comedy, Retro, Adventure

## Links

Trailer: https://www.youtube.com/watch?v=cA0T3so10CQ
Steam: https://store.steampowered.com/app/4346950/Johns_Quest/
Itch.io: https://benjamin-halko.itch.io/johns-quest

## Contact

- contact@benjaminhalko.dev
